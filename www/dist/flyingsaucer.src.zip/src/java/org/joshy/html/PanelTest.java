package org.joshy.html;

import java.awt.*;
import javax.swing.*;
import org.joshy.html.*;

public class PanelTest {
    

    public static void main(String[] args) throws Exception {
        HTMLPanel panel = new HTMLPanel();
        panel.setPreferredSize(new Dimension(300,500));
        panel.setDocument("test.xhtml");
        
        JScrollPane scroll = new JScrollPane(panel);
        panel.setViewportComponent(scroll);
        panel.setJScrollPane(scroll);
        
        JFrame frame = new JFrame();
        frame.getContentPane().add(scroll);
        frame.pack();
        frame.setVisible(true);
    }
    
}
