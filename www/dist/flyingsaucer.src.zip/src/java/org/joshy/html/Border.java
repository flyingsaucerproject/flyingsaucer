package org.joshy.html;

public class Border {
    public int top;
    public int bottom;
    public int left;
    public int right;
    
    public String toString() {
        return "Border: top = " + top + " right = " + right + " bottom = " + bottom + " left = " + left;
    }
}

