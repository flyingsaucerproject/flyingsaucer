package org.joshy.html.css;

public class DefaultCSSMarker {

}
