package org.joshy.html.forms;

import org.joshy.html.box.Box;

public class FormBox extends Box {
}
