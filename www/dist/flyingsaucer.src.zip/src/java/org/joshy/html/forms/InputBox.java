package org.joshy.html.forms;

import org.joshy.html.box.*;
import javax.swing.*;

public class InputBox extends BlockBox {
    public JComponent component;
    
    public String toString() {
        return "InputBox: " + super.toString();
    }
}




