package org.joshy.html.event;

public interface DocumentListener {
    public void documentLoaded();
}
