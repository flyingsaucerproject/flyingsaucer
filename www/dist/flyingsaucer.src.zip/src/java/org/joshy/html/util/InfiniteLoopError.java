package org.joshy.html.util;


public class InfiniteLoopError extends Error {
    public InfiniteLoopError(String message) {
        super(message);
    }
}
