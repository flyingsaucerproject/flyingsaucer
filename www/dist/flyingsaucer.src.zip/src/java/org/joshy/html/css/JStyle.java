package org.joshy.html.css;

import org.w3c.dom.css.*;
import org.w3c.css.sac.*;

public class JStyle {
    public CSSStyleSheet sheet;
    public SelectorList selector_list;
    public CSSRule rule;
    public CSSStyleDeclaration declaration;
}

