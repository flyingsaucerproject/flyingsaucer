package org.joshy.html.app.browser;


public class DemoMarker {

    public DemoMarker() {
    }
}
