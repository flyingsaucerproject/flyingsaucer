package org.joshy.html.net;

/**
The ResourceManager handles loading all resources for the rest of the
sytem. This includes xhtml documents, external css, and images.

*/
public class ResourceManager {
    /*
    protected boolean validating = true;
    
    public void setValidating(boolean validating) {
        this.validating = validating;
    }
    
    public Document loadDocument(URL url) {
        
    }
    */
}
