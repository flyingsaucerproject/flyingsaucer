Flying Saucer Version 0.02
http://xhtmlrenderer.dev.java.net/


This is a demonstration of Flying Saucer, the 100% Java HTML Renderer
written by Joshua Marinacci (joshy@joshy.org) and others at Java.net

To start just double click on the icon for flyingsaucer.jar
or type this on the command line:

    java -jar flyingsaucer.jar
    
Select a test from the 'Demo' menu to see different features.

If this is the source distro, type 'ant help' to see the available options
for compiling.

For more information see the project website at java.net
http://xhtmlrenderer.dev.java.net/
and join the mailing list.

Thanks,
    Joshua  (joshy@joshy.org)
    
    
Changes:

    V.02   July 10th 2004
        added preliminary forms support
        created a new browser application with
            history 
            forward / back / reload
            status bar
        started using java.util.logging
        fixed image loading bug that caused the browser to hang
        implemented new font resolver (should speed it up)
        
