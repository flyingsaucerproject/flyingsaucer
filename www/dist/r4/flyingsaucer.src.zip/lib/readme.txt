Readme.txt

Flying Saucer, /lib directory

joshy-common.jar: utility classes from Josh M, currently being phased out of use

Third-party Libraries
	ss-css2.jar: Steady State CSS2 Parser, release 0.9.3 from http://www.steadystate.com/css/
	
	junit.jar: release 3.8.1 from junit.org
	
	xalan.jar: release 2.3.1 from xml.apache.org/xalan
